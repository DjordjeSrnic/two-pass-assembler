#include "SymbolTable.h"

int SymbolTable::ID = 0;

SymbolTable::SymbolTable() {
	num = 0;
}

SymbolTable::~SymbolTable() {}

void SymbolTable::addEntry(std::string label, std::string section, TokenType type, int offset, ScopeType scope, bool defined, std::string flags) {
	symbolTable[label].label = label;
	symbolTable[label].section = section;
	symbolTable[label].type = type;
	symbolTable[label].offset = offset;
	symbolTable[label].scope = scope;
	symbolTable[label].defined = defined;
	symbolTable[label].flags = flags;
	symbolTable[label].id = ID++;
	num++;
}

std::map<std::string, SymTabEntry> SymbolTable::getTable() {
	return symbolTable;
}

SymTabEntry SymbolTable::getSymbol(std::string symbol) {
	return symbolTable[symbol];
}

void SymbolTable::changeSymbolToGlobal(std::string symbol) {
	symbolTable[symbol].scope = ScopeType::GLOBAL;
}

bool SymbolTable::symbolExists(std::string symbol) {
	std::map<std::string, SymTabEntry>::iterator it = symbolTable.find(symbol);
	
	if (it != symbolTable.end())
		return true;

	return false;
}

int SymbolTable::getSymbolOffset(std::string symbol) {
	return symbolTable[symbol].offset;
}

void SymbolTable::chengeSymbolTypeToLiteral(std::string symbol) {
	symbolTable[symbol].type = TokenType::LITERAL;
}

void SymbolTable::setSymbolValue(std::string symbol, int value) {
	symbolTable[symbol].offset = value;
}

int SymbolTable::getSize() {
	return num;
}
