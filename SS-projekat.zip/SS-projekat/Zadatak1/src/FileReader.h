#ifndef _FILEREADER_H
#define _FILEREADER_H

#define _CRT_SECURE_NO_WARNINGS
#define _SCL_SECURE_NO_WARNINGS
#include "SymbolTable.h"
#include "RelocationTable.h"
#include "Section.h"
#include "Enums.h"
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <map>
#include <algorithm> 
#include <string>
#include <sstream>
#include <bitset>
#include <queue>
#include <regex>
#include <list>

typedef struct {
	std::string left;
	std::string right;
	std::string section;
	ScopeType scopeType;
}TNSEntry;

class FileReader {
public:
	FileReader(std::string fileName);

	~FileReader();

	bool isOpen();

	void close();

	bool checkTNS();

	void doFirstPass();

	void checkGlobalSecondPass(std::queue<std::string> &tokens, std::string curSection);

	void checkExternSecondPass(std::queue<std::string> &tokens, std::string curSection);

	void checkDirectiveSecondPass(std::string curTokenS, std::queue<std::string> &tokens, std::string curSection);

	void checkInstructionSecondPass(std::queue<std::string> &tokens, std::string instr, std::string curSection);

	void doSecondPass();

	void split_line(std::string line, const char* delim, std::vector<std::string>& tokens);

	TokenType getTokenType(std::string token);

	int getNumOfOperandsForDirective(std::queue<std::string> &tokens);

	int getOperandValue(std::string operand, int toNextInstr, std::string oper);

	void checkDirectiveFirstPass(std::string dir, std::queue<std::string> &tokens);

	void checkInstructionFirstPass(std::string instr, std::queue<std::string> &tokens);

	void parseInputFile();

	void addToSection(std::string curSection, std::string content,int offset);

	int addAbsRelocation(std::string symbol, std::string section, std::string oper);

	int addPCRelRelocation(std::string symbol, std::string section, int toNextInstr);

	std::string formImmVal(std::string operand, int operandSize, bool isPCRel, int pad);

	std::string formShiftVal(std::string shift, AddressingType aType);

	std::string formMemVal(std::string operand);

	std::string formOperand(std::string operand, int operandSize, bool isDst, int pad);

	int getOperandLength(std::string operand, int operandSize);

	bool isImmDec(std::string operand);

	bool isImmHex(std::string operand);

	std::string Hex2Bin(std::string s);

	std::string Dec2Bin(std::string s);

	AddressingType findAddressingMode(std::string operand);

	std::string convertBinaryToHex(std::string binary);

	std::string formInstruction(std::queue<std::string>& tokens, std::string opstring, std::string opCode, int operandSize);

	bool checkDataValue(std::string type, int value);

	std::map<std::string, Section> sections;
	std::map<std::string, std::string> instructions;
	SymbolTable* symTab;
	RelocationTable* relTab;
private:
	std::ifstream myFile;
	int locationCounter;
	int numInst;
	bool firstPass, secondPass;
	std::string currentSection;
	std::string flags;
	int numSection;
	int numOfSections;
	int afterEndSymbolIndex;
	bool fileEnd, outOfRange;
	bool relocationSkip;
	static std::map<AddressingType, std::string> codeAddresingType;
	std::vector<std::vector<std::string>> lineTokens;
	std::map<std::string, std::string> registers;
	std::map<std::string, int> numOfOperands;
	std::map<std::string, std::string> binaryToHex;
	
	std::list<TNSEntry> tns;
};

#endif

