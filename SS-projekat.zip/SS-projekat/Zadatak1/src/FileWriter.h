#ifndef _FILEWRITER_H
#define _FILEWRITER_H

#define THROW(exceptionClass, message) throw exceptionClass(__FILE__, __LINE__, (message) )

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Section.h"
#include "RelocationTable.h"
#include "SymbolTable.h"

class FileWriter {
public:
	FileWriter(char* fname, std::map<std::string, Section> sections, int numSection, std::map<std::string, SymTabEntry> symbolTable, std::vector<RelTabEntry> relocationTable);

	~FileWriter();

	void close();

	void writeSymTab(std::ofstream& output);

	void writeSections(std::ofstream& output);

	std::string getTokenTypeS(TokenType type);

	void write();

private:
	char* fileName;
	std::ofstream outputFile;
	std::map<std::string, Section> sections;
	std::map<std::string, SymTabEntry> symTable;
	std::vector<RelTabEntry> relTable;
	int strNum;
	int relNum;
	int numOfSections;
	int numOfRelTables;
};

#endif
