#include "Section.h"

Section::Section(std::string _name, int _size) {
	name = _name;
	size = _size;
	num = 0;
}

Section::~Section() {}

void Section::addEntry(int offset, std::string hexContent) {
	std::pair<int, std::string> v(offset, hexContent);
	content.insert(v);
	num++;
}

std::map<int, std::string> Section::getContentTable() {
	return content;
}

std::string Section::getSectionName() {
	return name;
}

int Section::getSectionSize() {
	return size;
}

int Section::getTableSize() {
	return num;
}