#include "RelocationTable.h"

RelocationTable::RelocationTable() {
	num = 0;
}

RelocationTable::~RelocationTable() {}

void RelocationTable::addEntry(std::string section, int offset, RelocationType relType, std::string symbol, std::string oper) {
	RelTabEntry entry;
	entry.section = section;
	entry.offset = offset;
	entry.relType = relType;
	entry.symbol = symbol;
	entry.oper = oper;
	relTable.push_back(entry);
	num++;
}

std::vector<RelTabEntry> RelocationTable::getTable() {
	return relTable;
}

void RelocationTable::print() {
	for (int i = 0; i < num; i++)
		std::cout << i << ". " << relTable[i].section << " | " << relTable[i].offset << " | " << relTable[i].offset << " | " << relTable[i].relType << std::endl;
}

int RelocationTable::getSize() {
	return num;
}
