#ifndef _SYMBOLTABLE_H
#define _SYMBOLTABLE_H

#include <iostream>
#include <string>
#include <algorithm>
#include <map>
#include "Enums.h"

typedef struct {
	std::string label;
	std::string section;
	TokenType type;
	int offset;
	ScopeType scope;
	bool defined;
	std::string flags;
	int size;
	int id;
} SymTabEntry;

class SymbolTable
{
public:
	SymbolTable();

	~SymbolTable();

	void addEntry(std::string label, std::string section, TokenType type, int offset, ScopeType scope, bool defined, std::string flags);

	std::map<std::string, SymTabEntry> getTable();

	SymTabEntry getSymbol(std::string symbol);

	bool symbolExists(std::string symbol);

	void changeSymbolToGlobal(std::string symbol);

	int getSymbolOffset(std::string symbol);

	void setSymbolValue(std::string symbol, int value);

	void chengeSymbolTypeToLiteral(std::string symbol);

	int getSize();

private:
	static int ID;
	std::map<std::string, SymTabEntry> symbolTable;
	int num;
};

#endif