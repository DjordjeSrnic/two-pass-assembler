#include <iostream>
#include <sstream>
#include "FileReader.h"
#include "FileWriter.h"


int main(int argc, char** argv) {

	char* ulaz = argv[1];
	char* izlaz = argv[2];

	std::cout << "ULAZ: " << std::string(ulaz) << std::endl;

	std::cout << "IZLAZ: " << std::string(izlaz) << std::endl;

	FileReader *thisFile = new FileReader(ulaz);

	if (!thisFile->isOpen()) {
		std::cout << "Greska pri otvaranju falja!" << std::endl;
		return -1;
	}

	thisFile->doFirstPass();

	thisFile->doSecondPass();

	thisFile->close();

	FileWriter *output = new FileWriter(izlaz, thisFile->sections, thisFile->sections.size(),
		thisFile->symTab->getTable(), thisFile->relTab->getTable());

	output->write();
	output->close();

	std::cin.get();

	return 1;
}
