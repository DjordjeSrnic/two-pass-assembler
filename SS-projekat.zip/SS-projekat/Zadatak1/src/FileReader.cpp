#include "FileReader.h"

FileReader::FileReader(std::string fileName)
{
	myFile.open(fileName);

	if (myFile) {
		symTab = new SymbolTable();
		relTab = new RelocationTable();
		numSection = -1;
		numInst = 0;
		numOfSections = 0;
		firstPass = false;
		secondPass = false;
		fileEnd = false;
		outOfRange = false;

		numOfOperands["halt"] = 0;
		numOfOperands["xchg"] = 2;
		numOfOperands["int"] = 1;
		numOfOperands["mov"] = 2;
		numOfOperands["add"] = 2;
		numOfOperands["sub"] = 2;
		numOfOperands["mul"] = 2;
		numOfOperands["div"] = 2;
		numOfOperands["cmp"] = 2;
		numOfOperands["not"] = 1;
		numOfOperands["and"] = 2;
		numOfOperands["or"] = 2;
		numOfOperands["xor"] = 2;
		numOfOperands["test"] = 2;
		numOfOperands["shl"] = 2;
		numOfOperands["shr"] = 2;
		numOfOperands["push"] = 1;
		numOfOperands["pop"] = 1;
		numOfOperands["jmp"] = 1;
		numOfOperands["jeq"] = 1;
		numOfOperands["jne"] = 1;
		numOfOperands["jgt"] = 1;
		numOfOperands["call"] = 1;
		numOfOperands["ret"] = 0;
		numOfOperands["iret"] = 0;

		binaryToHex["0000"] = "0";
		binaryToHex["0001"] = "1";
		binaryToHex["0010"] = "2";
		binaryToHex["0011"] = "3";
		binaryToHex["0100"] = "4";
		binaryToHex["0101"] = "5";
		binaryToHex["0110"] = "6";
		binaryToHex["0111"] = "7";
		binaryToHex["1000"] = "8";
		binaryToHex["1001"] = "9";
		binaryToHex["1010"] = "A";
		binaryToHex["1011"] = "B";
		binaryToHex["1100"] = "C";
		binaryToHex["1101"] = "D";
		binaryToHex["1110"] = "E";
		binaryToHex["1111"] = "F";

		registers["r0"] = "0000";
		registers["r1"] = "0001";
		registers["r2"] = "0010";
		registers["r3"] = "0011";
		registers["r4"] = "0100";
		registers["r5"] = "0101";
		registers["r6"] = "0110";
		registers["r7"] = "0111";
		registers["pc"] = "0111";
		registers["sp"] = "0110";
		registers["psw"] = "1111";

		registers["r0h"] = "0000";
		registers["r1h"] = "0001";
		registers["r2h"] = "0010";
		registers["r3h"] = "0011";
		registers["r4h"] = "0100";
		registers["r5h"] = "0101";
		registers["r6h"] = "0110";
		registers["r7h"] = "0111";
		registers["pch"] = "0111";
		registers["sph"] = "0110";
		registers["pswh"] = "1111";

		registers["r0l"] = "0000";
		registers["r1l"] = "0001";
		registers["r2l"] = "0010";
		registers["r3l"] = "0011";
		registers["r4l"] = "0100";
		registers["r5l"] = "0101";
		registers["r6l"] = "0110";
		registers["r7l"] = "0111";
		registers["pcl"] = "0111";
		registers["spl"] = "0110";
		registers["pswl"] = "1111";
	}

}

FileReader::~FileReader() {
	delete symTab;
	delete relTab;
}

bool FileReader::isOpen() {
	return myFile.is_open();
}

std::map<AddressingType, std::string> FileReader::codeAddresingType =
{
	{ AddressingType::IMM, "000" },
	{ AddressingType::REG_DIR, "001" },
	{ AddressingType::REG_IND, "010" },
	{ AddressingType::REG_IND_POM8,"011" },
	{ AddressingType::REG_IND_POM16,"100" },
	{ AddressingType::MEM, "101" },
};

void FileReader::close() {
	myFile.close();
}

bool FileReader::checkTNS() {
	std::regex math{ "(([a-zA-Z_][a-zA-Z0-9]*)|(0x[0-9a-fA-F]+)|([0-9]+))([-+*/])(([a-zA-Z_][a-zA-Z0-9]*)|(0x[0-9a-fA-F]+)|([0-9]+))" };
	std::regex sym{ "(([a-zA-Z_][a-zA-Z0-9]*))" };
	bool change = false, firstPass = true;
	int size = tns.size();
	std::list <TNSEntry> ::iterator it;
	while ((change || firstPass) && tns.size()!=0) {
		firstPass = false;
		change = false;
		for (it = tns.begin(); it != tns.end();) {
			std::string right = it->right;
			if (regex_match(right, sym)) {
				bool symExists = symTab->symbolExists(right);
				if (symExists) {
					if (symTab->getSymbol(right).defined == false)
						return false;
					int val = symTab->getSymbolOffset(right);
					symTab->addEntry(it->left, it->section, TokenType::LITERAL, val, it->scopeType, true, "");
					it = tns.erase(it);
					change = true;
				}
				else {
					++it;
					change = false;
				}
			}
			else if (regex_match(right, math)) {
				std::vector<std::string> opTokens;
				split_line(right, "+-", opTokens);
				std::string op1 = opTokens[0];
				std::string op2 = opTokens[1];

				TokenType op1Type = getTokenType(op1);
				TokenType op2Type = getTokenType(op2);

				if (op1Type == TokenType::SYMBOL)
					if (!symTab->symbolExists(op1)) {
						change = false;
						++it;
						continue;
					}

				if (op2Type == TokenType::SYMBOL)
					if (!symTab->symbolExists(op2)) {
						change = false;
						++it;
						continue;
					}

				std::string oper = right.substr(op1.length(), 1);

				int value1=0;
				int value2=0;
				
				
				if (op1Type == TokenType::SYMBOL)
					value1 = symTab->getSymbolOffset(op1);
				else
					value1 = getOperandValue(op1, 0,"");

				if (op2Type == TokenType::SYMBOL)
					value2 = symTab->getSymbolOffset(op2);
				else
					value2 = getOperandValue(op2, 0,"");
				int opValue;
				if (oper == "+")
					opValue = value1 + value2;
				else
					opValue = value1 - value2;

				symTab->addEntry(it->left, it->section, TokenType::LITERAL, opValue, it->scopeType, true, "");

				it = tns.erase(it);
				change = true;
			}
			else
				return false;
		}
	}
	if (tns.size() == 0)
		return true;
	else
		return false;
}

void FileReader::split_line(std::string line, const char* delim, std::vector<std::string>& tokens) {
	size_t start = line.find_first_not_of(delim);

	size_t end = start;
	while (start != std::string::npos) {
		end = line.find_first_of(delim, start);

		tokens.push_back(line.substr(start, end - start));

		//std::cout << line.substr(start, end - start) << " ";

		start = line.find_first_not_of(delim, end);
	}
}

TokenType FileReader::getTokenType(std::string token) {
	TokenType typeT = TokenType::INCORRECT;
	std::string ulaz = token;
	std::regex label{ "([a-zA-Z][a-zA-Z0-9_]*):" };
	std::regex section{ "(\\.)(text|data|bss|section)" };
	std::regex ext_glb{ "(\\.)(global|extern)" };
	std::regex directive{ "\\.(align|byte|word|skip|equ)" };
	std::regex instruction{ "(halt|xchg|int|mov|add|sub|mul|div|cmp|not|and|or|xor|test|shl|shr|push|pop|jmp|jeq|jne|jgt|call|ret|iret)(b|w)?" };
	std::regex symbol{ ("(([a-zA-Z_][a-zA-Z0-9]*))") };
	std::regex op_dec{ ("([0-9]+)") };
	std::regex op_hex{ ("0x([0-9a-fA-F]+)") };
	std::regex op_sym_value{ "(\\&)([a-zA-Z_][a-zA-Z0-9]*)" };
	std::regex end{ "(\\.)(end)" };

	if (std::regex_match(ulaz, ext_glb))
		return  TokenType::EXT_GLB;
	if (std::regex_match(ulaz, label))
		return TokenType::LABEL;
	if (std::regex_match(ulaz, directive))
		return TokenType::DIRECTIVE;
	if (std::regex_match(ulaz, section))
		return TokenType::SECTION;
	if (std::regex_match(ulaz, instruction))
		return TokenType::INSTRUCTION;
	if (std::regex_match(ulaz, symbol))
		return TokenType::SYMBOL;
	if (std::regex_match(ulaz, op_dec))
		return TokenType::OP_DEC;
	if (std::regex_match(ulaz, op_hex))
		return TokenType::OP_HEX;
	if (std::regex_match(ulaz, op_sym_value))
		return TokenType::OP_SYM_VALUE;
	if (std::regex_match(ulaz, end))
		return TokenType::END;
	return typeT;
}

void FileReader::parseInputFile() {
	std::string line;
	while (getline(myFile, line)) {
		//std::cout << line << std::endl;
		line.erase(line.length() - 1);

		std::vector<std::string> tokens;
		split_line(line, " ,\t", tokens);
		if (tokens.size() == 0)
			continue;
		if (tokens[0] == ".end") {
			lineTokens.push_back(tokens);
			break;
		}
		lineTokens.push_back(tokens);
	}

}

int FileReader::getNumOfOperandsForDirective(std::queue<std::string> &tokens) {
	int ret = 0;
	while (!tokens.empty()) {
		tokens.pop();
		ret++;
	}
	return ret;
}

int FileReader::getOperandValue(std::string operand, int toNextInstr, std::string oper) {
	std::regex op_dec{ ("([0-9]+)") };
	std::regex op_hex{ ("0x([0-9a-fA-F]+)") };
	std::regex op_sym_value{ "(\\&)([a-zA-Z_][a-zA-Z0-9]*)" };
	std::regex op_sym_mem{ "([a-zA-Z_][a-zA-Z0-9]*)" };
	std::regex op_mem{ "(\\*)([0-9]+)" };
	std::regex op_reg{ "(r)([0-7])" };
	std::regex op_reg_ind_value{ "(r)([0-7])(\\[)([0-9]+)(\\])" };
	std::regex op_reg_ind_sym{ "(r)([0-7])(\\[)([a-zA-Z_][a-zA-Z0-9]*)(\\])" };
	std::regex op_$_label{ "(\\$)([a-zA-Z_][a-zA-Z0-9]*)" };

	std::smatch match;
	if (regex_match(operand, match, op_dec)) {
		return stoi(match[1]);
	}
	if (regex_match(operand, match, op_hex)) {
		return stoi(match[1],0,16);
	}
	if (regex_match(operand, match, op_sym_value)) {
		std::string symS = match[2];
		SymTabEntry sym = symTab->getSymbol(symS);
		TokenType opT = sym.type;
		bool exists = symTab->symbolExists(symS);
		if (exists){
			if (opT == TokenType::LITERAL)
				return symTab->getSymbolOffset(symS);
		}
		return addAbsRelocation(symS, currentSection, oper);
	}
	if (regex_match(operand, match, op_sym_mem)) {
		std::string symS = operand;
		SymTabEntry sym = symTab->getSymbol(symS);
		TokenType opT = sym.type;
		bool exists = symTab->symbolExists(symS);
		if (exists){
			if (opT == TokenType::LITERAL)
				throw std::runtime_error("Symbol is a literal.");
		}
		return addAbsRelocation(symS, currentSection, oper);
	}
	if (regex_match(operand, match, op_mem)) {
		return stoi(match[2]);
	}
	if (regex_match(operand, match, op_$_label)) {
		std::string symS = match[2];
		SymTabEntry sym = symTab->getSymbol(symS);
		TokenType opT = sym.type;
		bool exists = symTab->symbolExists(symS);
		if (exists){
			if (opT == TokenType::LITERAL)
				throw std::runtime_error("Symbol is a literal.");
		}
		return addPCRelRelocation(symS, currentSection, toNextInstr);
	}
	throw std::runtime_error("Operand type is not recognized.");
	return 0;
}

void FileReader::checkDirectiveFirstPass(std::string dir, std::queue<std::string> &tokens) {
	if (dir == ".align") {
		std::string op = tokens.front();
		tokens.pop();
		TokenType opT = getTokenType(op);
		if (opT != TokenType::OP_DEC && opT != TokenType::OP_HEX)
			throw std::runtime_error("Directive .align needs decimal or hex operand.");
		int value = getOperandValue(op,0,"");
		if (!(locationCounter % value == 0)) {
			locationCounter = locationCounter / value * value + value;
		}
		return;
	}
	if (dir == ".skip") {
		std::string op = tokens.front();
		tokens.pop();
		TokenType opT = getTokenType(op);
		if (opT != TokenType::OP_DEC && opT != TokenType::OP_HEX)
			throw std::runtime_error("Directive .skip needs decimal or hex operand.");
		int value = getOperandValue(op,0,"");
		locationCounter += value;
		return;
	}
	if (dir == ".equ") {
		std::string sym = tokens.front();
		tokens.pop();
		bool symbolExists = symTab->symbolExists(sym);

		if (symbolExists) {
			SymTabEntry symbol = symTab->getSymbol(sym);
			if (symbol.defined)
				throw std::runtime_error("Symbol is already defined.");
		}
		else {
			std::regex num_dec{ "([0-9]+)" };
			std::regex num_hex{ "(0x[0-9a-fA-F]+)" };
			std::string value = tokens.front();
			tokens.pop();
			
			if (regex_match(value, num_dec))
				symTab->addEntry(sym, currentSection, TokenType::LITERAL, stoi(value), ScopeType::LOCAL, true, "");
			else if (regex_match(value, num_hex))
				symTab->addEntry(sym, currentSection, TokenType::LITERAL, stoi(value,0,16), ScopeType::LOCAL, true, "");
			/*else {
				TNSEntry tnsEntry;
				tnsEntry.left = sym;
				tnsEntry.right = value;
				tnsEntry.section = currentSection;
				tns.push_back(tnsEntry);
			}*/
		}
	}
	if (dir == ".byte") {
		locationCounter += getNumOfOperandsForDirective(tokens);
		return;
	}
	if (dir == ".word") {
		locationCounter += 2*getNumOfOperandsForDirective(tokens);
		return;
	}
}

void FileReader::checkInstructionFirstPass(std::string instr, std::queue<std::string> &tokens) {
	std::smatch match;
	std::regex instruction{ "(halt|xchg|int|mov|add|sub|mul|div|cmp|not|and|or|xor|test|shl|shr|push|pop|jmp|jeq|jne|jgt|call|ret|iret)(b|w)?" };

	std::regex_match(instr, match, instruction);
	std::string inst = match[1];
	int size = numOfOperands[inst];
	locationCounter += 1;
	if (size == 0)
		return;

	int operandSize = 8;
	if (match[2] == 'w')
		operandSize = 16;
	std::string op1 = tokens.front();
	tokens.pop();
	locationCounter += getOperandLength(op1, operandSize);

	if (size == 1)
		return;

	std::string op2 = tokens.front();
	tokens.pop();
	locationCounter += getOperandLength(op2, operandSize);
}

void FileReader::doFirstPass() {
	parseInputFile();
	locationCounter = 0;
	currentSection = "und";
	TokenType currToken;
	std::string currTokenS;
	symTab->addEntry("und", currentSection, TokenType::SECTION, 0, ScopeType::LOCAL, true, "");
	for (const auto &tokens : lineTokens) {
		std::queue<std::string> tokensqueue;
		for (const auto &token : tokens)
			tokensqueue.push(token);
		
		currTokenS = tokensqueue.front();
		currToken = getTokenType(currTokenS);
		std::string labelName;

		if (currToken == LABEL) {
			labelName = currTokenS.substr(0, currTokenS.size() - 1);
			tokensqueue.pop();
			bool exists = symTab->symbolExists(labelName);
			if (exists)
				throw std::runtime_error("Symbol already exists.");
			symTab->addEntry(labelName, currentSection, currToken, locationCounter, ScopeType::LOCAL, true, "");
			if (tokensqueue.empty())
				continue;
		}
		currTokenS = tokensqueue.front();
		std::cout << "CURRTOKENS: " << currTokenS << std::endl;
		currToken = getTokenType(currTokenS);
		tokensqueue.pop();
		std::string flags = "";
		switch (currToken)
		{
		case LABEL:
			throw std::runtime_error("Double label definition in the same row.");
			break;
		case DIRECTIVE:
			if (currentSection == "und")
				throw std::runtime_error("Directives can't be defined outside of a section.");
			checkDirectiveFirstPass(currTokenS, tokensqueue);
			break;
		case SECTION:
			if (currentSection != "und") 
				sections.insert({ currentSection, Section(currentSection, locationCounter) });
			
			if (currTokenS == ".section") {
				currentSection = tokensqueue.front();
				locationCounter = 0;
				tokensqueue.pop();
				
				if (!tokensqueue.empty()) {
					flags = tokensqueue.front();
					int posBeg = flags.find_first_of('"');
					int posEnd = flags.find_last_of('"');
					flags = flags.substr(posBeg + 1, posEnd - posBeg - 1);
					tokensqueue.pop();
				}
			
				symTab->addEntry(currentSection, currentSection, currToken, locationCounter, ScopeType::LOCAL, true, flags);
			}
			else {
				currentSection = currTokenS;
				locationCounter = 0;
				if (currentSection == ".text")
					flags = "PXR";
				else if (currentSection == ".data")
					flags = "PRW";
				else if (currentSection == ".bss")
					flags = "RW";
				else
					throw std::runtime_error("Section with this name doesn't exist!");

				symTab->addEntry(currentSection, currentSection, currToken, locationCounter, ScopeType::LOCAL, true, flags);
			}
			
			break;
		case EXT_GLB:
			if (currentSection != "und")
				throw std::runtime_error(".global or .extern directive must be defined before any section.");
			
			while (!tokensqueue.empty())
					tokensqueue.pop();	
			break;
		case INSTRUCTION:
			checkInstructionFirstPass(currTokenS, tokensqueue);
			break;
		case END:
			sections.insert({ currentSection, Section(currentSection, locationCounter) });
			break;
		default:
			throw std::runtime_error("Type of a token at the start of a line during first run is not recognized.");
			break;
		}
	}
	std::cout<<"FINISHED FIRST PASS" << std::endl;	
}

void FileReader::checkGlobalSecondPass(std::queue<std::string> &tokens, std::string curSection) {
	while (!tokens.empty()) {
		std::string currTokenS = tokens.front();
		TokenType currToken = getTokenType(currTokenS);
		tokens.pop();
		if (currToken != SYMBOL)
			throw std::runtime_error("Expected symbol after .global.");
		
		bool symbolExsts = symTab->symbolExists(currTokenS);
		if (symbolExsts)
			symTab->changeSymbolToGlobal(currTokenS);
		else 
			symTab->addEntry(currTokenS, currentSection, currToken, locationCounter, ScopeType::GLOBAL, false, "");
	}
}

void FileReader::checkExternSecondPass(std::queue<std::string> &tokens, std::string curSection) {
	while (!tokens.empty()) {
		std::string currTokenS = tokens.front();
		TokenType currToken = getTokenType(currTokenS);
		tokens.pop();
		if (currToken != SYMBOL)
			throw std::runtime_error("Expected symbol after .extern.");

		bool symbolExists = symTab->symbolExists(currTokenS);
		if (symbolExists)
			throw std::runtime_error("You can't redefine external symbol.");
		symTab->addEntry(currTokenS, currentSection, currToken, locationCounter, ScopeType::GLOBAL, false, "");
	}
}

void FileReader::checkDirectiveSecondPass(std::string currTokenS, std::queue<std::string> &tokens, std::string curSection) {
	if (currTokenS == ".align") {
		int oldCounter = locationCounter;
		std::string op = tokens.front();
		tokens.pop();
		TokenType opT = getTokenType(op);
		int value = getOperandValue(op,0,"");

		if (!(locationCounter % value == 0)) {
			locationCounter = locationCounter / value * value + value;
		}

		auto section = sections.find(currentSection);
		std::string content = "";
		std::string hexContent;

		for (int i = 0; i < locationCounter - oldCounter; i++)
			content += "00000000";

		if (content != "") {
			hexContent = convertBinaryToHex(content);
			section->second.addEntry(oldCounter, hexContent);
		}
		
		return;
	}

	if (currTokenS == ".skip") {
		std::string op = tokens.front();
		tokens.pop();
		TokenType opT = getTokenType(op);
		if (opT != TokenType::OP_DEC && opT != TokenType::OP_HEX)
			throw std::runtime_error("Wrong type of operand for .skip directive,has to be either decimal or hex number.");
		int opValue = getOperandValue(op,0,"");
		auto section = sections.find(currentSection);
		if (section == sections.end()) 
			std::cout << "Couldn't find .skip directive section. " << std::endl;
		std::string content = "";
		std::string hexContent;

		for (int i = 0; i < opValue; i++)
			content += "00000000";

		hexContent = convertBinaryToHex(content);
		section->second.addEntry(locationCounter, hexContent);
		locationCounter += opValue;
		return;
	}
	if (currTokenS == ".byte") {

		while (!tokens.empty()) {
			std::string operand = tokens.front();
			tokens.pop();
			TokenType opT = getTokenType(operand);
			if (opT != TokenType::OP_DEC && opT != TokenType::OP_HEX)
				throw std::runtime_error("Directive .byte can be written only with decimal or hex operands.");
			int opValue = getOperandValue(operand, 0,"");

			bool checkVal = checkDataValue("byte", opValue);
			if (!checkVal)
				throw std::runtime_error("Byte value is outside of boundaries.");	

			std::string op = std::bitset<8>(opValue).to_string();
			op = convertBinaryToHex(op);
			auto section = sections.find(currentSection);
			section->second.addEntry(locationCounter, op);
			locationCounter++;
		}
		return;
	}

	if (currTokenS == ".word") {
		while (!tokens.empty()) {
			std::regex math{"(([a-zA-Z_][a-zA-Z0-9]*)|(0x[0-9a-fA-F]+)|([0-9]+))([-+*/])(([a-zA-Z_][a-zA-Z0-9]*)|(0x[0-9a-fA-F]+)|([0-9]+))"};
			std::string operand = tokens.front();
			if (regex_match(operand, math)) {
				std::string delim = "+-";
				std::vector<std::string> opTokens;
				split_line(operand, "+-", opTokens);
				std::string op1 = opTokens[0];
				std::string op2 = opTokens[1];
				opTokens.pop_back();

				std::string oper = operand.substr(op1.length(), 1);
				TokenType op1T = getTokenType(op1);
				TokenType op2T = getTokenType(op2);
			
				int value1;
				int value2;
				if (op1T == TokenType::SYMBOL) {
					value1 = getOperandValue(op1, 1, "+");
					value1 = 0;
				}
				else
					value1 = getOperandValue(op1, 1, "");
				
				if (op2T == TokenType::SYMBOL) {
					value2 = getOperandValue(op2, 1, oper);
					value2 = 0;
				}
				else
					value2 = getOperandValue(op2, 1, "");
				int opValue;
				if (oper == "+")
					opValue = value1 + value2;
				else
					opValue = value1 - value2;

				std::string op = std::bitset<16>(opValue).to_string();

				op = convertBinaryToHex(op.substr(8, 8) + op.substr(0, 8));
				auto section = sections.find(currentSection);
				section->second.addEntry(locationCounter, op);
				locationCounter += 2;
				return;
			}
				
			tokens.pop();
			TokenType opT = getTokenType(operand);
			if (opT != TokenType::OP_DEC && opT != TokenType::OP_HEX && opT != TokenType::OP_SYM_VALUE)
				throw std::runtime_error("Directive .word can be written only with decimal or hex or symbol value operand or math expression.");
	
			int opValue;
			std::string op;
			if (opT == TokenType::OP_DEC || opT == TokenType::OP_HEX)
				opValue = getOperandValue(operand, 0, "");
			else {
				std::string opr = "";
				if (opT == TokenType::OP_SYM_VALUE)
					opr = operand.substr(1);
				bool symExists = symTab->symbolExists(opr);
				if (!symExists)
					throw std::runtime_error("Symbol doesn't exist!");
				opValue = getOperandValue(operand, 0, "");
			}

			bool checkVal = checkDataValue("word", opValue);
			if (!checkVal)
				throw std::runtime_error("Word value is outside of boundaries.");			

			op = std::bitset<16>(opValue).to_string();
			op = convertBinaryToHex(op.substr(8,8) + op.substr(0,8));
			auto section = sections.find(currentSection);
			section->second.addEntry(locationCounter, op);
			locationCounter+=2;
		}
		return;
	}
}

void FileReader::checkInstructionSecondPass(std::queue<std::string> &tokens, std::string currToken, std::string curSection) {
	std::smatch match;
	std::string opCode = "";
	std::string formedInstruction = "";
	int offset = locationCounter;
	std::regex instruction{ "(halt|xchg|int|mov|add|sub|mul|div|cmp|not|and|or|xor|test|shl|shr|push|pop|jmp|jeq|jne|jgt|call|ret|iret)(b|w)?" };
	regex_match(currToken, match, instruction);
	std::string instructionName = match[1];

	int numOperand = numOfOperands[instructionName];
	int operandSize = 8;
	if (match[2] == 'w')
		operandSize = 16;

	switch (numOperand) {
	case 2:
		if (instructionName == "xchg")
			opCode += "00010";
		else if (instructionName == "mov")
			opCode += "00100";
		else if (instructionName == "add")
			opCode += "00101";
		else if (instructionName == "sub")
			opCode += "00110";
		else if (instructionName == "mul")
			opCode += "00111";
		else if (instructionName == "div")
			opCode += "01000";
		else if (instructionName == "cmp")
			opCode += "01001";
		else if (instructionName == "and")
			opCode += "01011";
		else if (instructionName == "or")
			opCode += "01100";
		else if (instructionName == "xor")
			opCode += "01101";
		else if (instructionName == "test")
			opCode += "01110";
		else if (instructionName == "shl")
			opCode += "01111";
		else if (instructionName == "shr")
			opCode += "10000";

		formedInstruction = formInstruction(tokens, instructionName, opCode, operandSize);
		break;
	case 1:
		if (instructionName == "int")
			opCode += "00011";
		else if (instructionName == "not")
			opCode += "01010";
		else if (instructionName == "push")
			opCode += "10001";
		else if (instructionName == "pop")
			opCode += "10010";
		else if (instructionName == "jmp")
			opCode += "10011";
		else if (instructionName == "jeq")
			opCode += "10100";
		else if (instructionName == "jne")
			opCode += "10101";
		else if (instructionName == "jgt")
			opCode += "10110";
		else if (instructionName == "call")
			opCode += "10111";

		formedInstruction = formInstruction(tokens, instructionName, opCode, operandSize);
		break;
	case 0:
		if (instructionName == "halt")
			opCode += "00001";
		else if (instructionName == "ret")
			opCode += "11000";
		else if (instructionName == "iret")
			opCode += "11001";

		formedInstruction = formInstruction(tokens, instructionName, opCode, operandSize);
		break;
	}

	std::cout << "\n" << instructionName << ": " << convertBinaryToHex(formedInstruction) << "\n" << std::endl;
	addToSection(currentSection, formedInstruction, offset);
}

void FileReader::doSecondPass() {
	locationCounter = 0;
	numInst = 0;
	currentSection = "und";
	TokenType currToken;
	std::string currTokenS;
	for (const auto &tokens : lineTokens) {
		std::queue<std::string> tokensqueue;
		for (const auto &token : tokens) {
			tokensqueue.push(token);
		}
		currTokenS = tokensqueue.front();
		currToken = getTokenType(currTokenS);
		if (currToken == LABEL) {
			tokensqueue.pop();
			if (tokensqueue.empty())
				continue;
		}
		currTokenS = tokensqueue.front();
		currToken = getTokenType(currTokenS);
		tokensqueue.pop();
		
		switch (currToken)
		{
		case EXT_GLB:
			if (currTokenS == ".global")
				checkGlobalSecondPass(tokensqueue, currentSection);
			else 
				checkExternSecondPass(tokensqueue, currentSection);
			break;
		case DIRECTIVE:
			checkDirectiveSecondPass(currTokenS, tokensqueue, currentSection);
			break;
		case SECTION:
			locationCounter = 0;
			if (currTokenS == ".section")
				currentSection = tokensqueue.front();
			else
				currentSection = currTokenS;
			break;
		case INSTRUCTION:
			checkInstructionSecondPass(tokensqueue, currTokenS, currentSection);
		default:
			break;
		}
	}
}

void FileReader::addToSection(std::string curSection, std::string content, int offset) {
	auto sec = sections.find(curSection);

	std::string hexContent = convertBinaryToHex(content);

	sec->second.addEntry(offset, hexContent);
}

int FileReader::addAbsRelocation(std::string symbol, std::string section, std::string oper) {
	bool symExists = symTab->symbolExists(symbol);
	if (!symExists) 
		throw std::runtime_error("Symbol used is not defined.");
	SymTabEntry sym = symTab->getSymbol(symbol);
	if (sym.type == TokenType::LITERAL)
		throw std::runtime_error("Symbol is a literal");
	if (sym.scope == ScopeType::GLOBAL) {
		relTab->addEntry(section, locationCounter, RelocationType::ABS, symbol, oper);
		return 0;
	}
	else {
		std::string sectionName = sym.section;
		if (oper == "")
			relTab->addEntry(currentSection, locationCounter, RelocationType::ABS, sectionName, oper);
		else
			relTab->addEntry(currentSection, locationCounter, RelocationType::ABS, symbol, oper);
		return sym.offset;
	}
}

int FileReader::addPCRelRelocation(std::string symbol, std::string section, int toNextPC) {
	bool symExists = symTab->symbolExists(symbol);
	if (!symExists) 
		throw std::runtime_error("Symbol used is not defined.");
	SymTabEntry sym = symTab->getSymbol(symbol);
	if (sym.type == TokenType::LITERAL)
		throw std::runtime_error("Symbol is a literal");
	if (sym.scope == ScopeType::GLOBAL){
		relTab->addEntry(currentSection, locationCounter, RelocationType::PCREL, symbol, "");
		return -toNextPC;
	}
	else {
	if (sym.section != currentSection) {
		relTab->addEntry(currentSection, locationCounter, RelocationType::PCREL, sym.section, "");
		return sym.offset - toNextPC;
	}
	else
		return sym.offset - (locationCounter + toNextPC);
	}
}

std::string FileReader::Hex2Bin(std::string str) {
	std::string out;
	std::string s = str.substr(2);
	for (auto i : s) {
		uint8_t n;
		if (i <= '9' && i >= '0')
			n = i - '0';
		else
			n = 10 + i - 'A';
		for (int8_t j = 3; j >= 0; --j)
			out.push_back((n & (1 << j)) ? '1' : '0');
	}

	return out;
}

std::string FileReader::Dec2Bin(std::string s) {

	int decimal;
	std::stringstream ss(s);
	ss >> decimal;

	int coefficient = -1, numerator = decimal;
	std::string binary = "";

	while (coefficient != 0) {
		if (numerator % 2 == 1)
			binary += "1";
		else
			binary += "0";
		coefficient = numerator / 2;
		numerator = coefficient;
	}

	std::string new_string = "";
	for (int i = (binary.length() - 1); i >= 0; i--)
		new_string += binary.at(i);
	return new_string;
}

std::string FileReader::formImmVal(std::string operand, int operandSize, bool isPCRel, int pad) {
	if (operand[0] == '&' || operand[0] == '$') {

		std::string label = operand.substr(1);

		int ret;
		
		std::string type;
		if (operand[0] == '$') {
			type = "R_386_PC16";
			ret = addPCRelRelocation(label, currentSection, pad + 2);
		}
		else {
			type = "R_386_16";
			bool exists = symTab->symbolExists(label);
			SymTabEntry sym = symTab->getSymbol(label);
			TokenType opT = sym.type;
			if (exists)
				if (opT == TokenType::LITERAL)
					ret = sym.offset;
			if (opT != LITERAL)
				ret = addAbsRelocation(label, currentSection,"");
		}
		locationCounter += 2;

		std::string binOffset = std::bitset<16>(ret).to_string();

		std::string retVal = binOffset;

		std::string high = retVal.substr(0, 8);
		std::string low = retVal.substr(8, 8);
		retVal = low + high;

		return retVal;
	}
	else {
		std::string intVal = "";
		if (isImmDec(operand))
			intVal += Dec2Bin(operand);
		else if (isImmHex(operand))
			intVal += Hex2Bin(operand);
		else
			throw std::runtime_error("Token type not recognized.");

		std::string binStr = "" + intVal;
		std::string retVal = "";
		if (operandSize == 8) {
			int bitsRemToByte = 8 - binStr.length();
			for (int i = 0; i < bitsRemToByte; i++)
				retVal += "0";

			locationCounter += 1;
			retVal += binStr.substr(0, 8);
		}
		else {
			int bitsRemToByte = 16 - binStr.length();
			for (int i = 0; i < bitsRemToByte; i++)
				retVal += "0";
			retVal += binStr;
			std::string high = retVal.substr(0, 8);
			std::string low = retVal.substr(8, 8);
			retVal = low + high;
			locationCounter += 2;
		}
		return retVal;
	}
}

std::string FileReader::formShiftVal(std::string shift, AddressingType aType) {
	std::regex op_sym{ "([a-zA-Z_][a-zA-Z0-9]*)" };

	if (isImmDec(shift) || isImmHex(shift)) {

		std::string intVal = "";
		if (isImmDec(shift))
			intVal += Dec2Bin(shift);
		else if (isImmHex(shift))
			intVal += Hex2Bin(shift);

		std::string binStr = "" + intVal;
		std::string retVal = "";
		if (aType == AddressingType::REG_IND_POM8) {
			int bitsRemToByte = 8 - binStr.length();
			for (int i = 0; i < bitsRemToByte; i++)
				retVal += "0";
			retVal += binStr;
			locationCounter += 1;
		}
		else {
			int bitsRemToByte = 16 - binStr.length();
			for (int i = 0; i < bitsRemToByte; i++)
				retVal += "0";
			retVal += binStr;
			std::string high = retVal.substr(0, 8);
			std::string low = retVal.substr(8, 8);
			retVal = low + high;
			locationCounter += 2;
		}
		return retVal;
	}
	else {
		int val;

		std::string type = "R_386_16";
		bool exists = symTab->symbolExists(shift);
		SymTabEntry sym = symTab->getSymbol(shift);
		TokenType opT = sym.type;
		if (exists)
			if (opT == TokenType::LITERAL)
				val = sym.offset;	
		if (opT != TokenType::LITERAL)
			val = addAbsRelocation(shift, currentSection,"");		

		
		std::string binOffset = std::bitset<16>(val).to_string();

		std::string retVal = "";

		std::string high = binOffset.substr(0, 8);
		std::string low = binOffset.substr(8, 8);
		retVal = low + high;
		locationCounter += 2;

		return retVal;
	}
}

std::string FileReader::formMemVal(std::string operand) {
	
	if (operand[0] == '*') {
		std::string numVal = operand.substr(1);
		std::string binStr = "";
		if (isImmHex(numVal))
			binStr = Hex2Bin(numVal);
		else if (isImmDec(numVal))
			binStr = Dec2Bin(numVal);
		else
			throw std::runtime_error("Not a decimal or hex value for mem address.");


		std::string retVal = "";
		int bitsRemToByte = 16 - binStr.length();
		for (int i = 0; i < bitsRemToByte; i++)
			retVal += "0";
		retVal += binStr;

		std::string high = retVal.substr(0, 8);
		std::string low = retVal.substr(8, 8);
		retVal = low + high;
		locationCounter += 2;

		return retVal;
	}
	else {

		int val;

		std::string type = "R_386_16";
		bool exists = symTab->symbolExists(operand);
		SymTabEntry sym = symTab->getSymbol(operand);
		TokenType opT = sym.type;
		if (exists) 
			if (opT == TokenType::LITERAL)
				val = sym.offset;	
		if (opT != TokenType::LITERAL)
			val = addAbsRelocation(operand, currentSection,"");		

		std::string binOffset = std::bitset<16>(val).to_string();

		std::string retVal = "";

		std::string high = binOffset.substr(0, 8);
		std::string low = binOffset.substr(8, 8);
		retVal = low + high;
		locationCounter += 2;

		return retVal;
	}
}

std::string FileReader::formOperand(std::string operand, int operandSize, bool isDst, int pad) {

	std::string retHex = "";

	AddressingType addrType = findAddressingMode(operand);

	retHex += codeAddresingType[addrType];

	switch (addrType) {
	case 0: {
		retHex += "00000";
		locationCounter += 1;
		retHex += formImmVal(operand, operandSize, false, 0);
		break;
	}
	case 1: {
		retHex += registers[operand];
		if (operandSize == 8) {
			char chr = operand[operand.length() - 1];
			if (chr == 'l')
				retHex += "0";
			else if (chr == 'h')
				retHex += "1";
			else
				retHex += "0";
		}
		else
			retHex += "0";
		locationCounter += 1;
		break;
	}
	case 2: {
		int posBeg = operand.find('[');
		int posEnd = operand.find(']');
		retHex += registers[operand.substr(posBeg + 1, posEnd - posBeg - 1)];
		retHex += "0";
		locationCounter += 1;
		break;
	}
	case 3: {
		int posBeg = operand.find('[');
		int posEnd = operand.find(']');
		if (posEnd != 0) {
			std::string reg = operand.substr(0, posBeg);
			retHex += registers[reg];
			retHex += "0";
			std::string shift = operand.substr(posBeg + 1, posEnd - posBeg - 1);
			locationCounter += 1;
			retHex += formShiftVal(shift, addrType);
		}
		else {
			retHex += registers["pc"];
			retHex += "0";
			locationCounter += 1;
			retHex += formImmVal(operand, 8, true, pad);
		}
		break;
	}
	case 4: {
		int posBeg = operand.find('[');
		int posEnd = operand.find(']');
		if (posEnd > 0) {
			std::string reg = operand.substr(0, posBeg);
			retHex += registers[reg];
			retHex += "0";
			locationCounter += 1;
			std::string shift = operand.substr(posBeg + 1, posEnd - posBeg - 1);
			retHex += formShiftVal(shift, addrType);
		}
		else {
			retHex += registers["pc"];
			retHex += "0";
			locationCounter += 1;
			retHex += formImmVal(operand, 16, true, pad);
		}
		break;
	}
	case 5: {
		retHex += "00000";
		locationCounter += 1;
		retHex += formMemVal(operand);
		break;
	}
	default:
		throw std::runtime_error("Wrong addressing type.");
	}
	return retHex;
}

int FileReader::getOperandLength(std::string operand, int operandSize) {
	AddressingType aType = findAddressingMode(operand);

	switch (aType) {
	case 0: {
		if (isImmDec(operand) || isImmHex(operand))
			return operandSize / 8 + 1;
		else
			return 3;
	}
	case 1:
		return 1;
	case 2:
		return 1;
	case 3:
		return 2;
	case 4:
		return 3;
	case 5: 
		return 3;
	default:
		throw std::runtime_error("Wrong addressing type.");
	}
}

bool FileReader::isImmDec(std::string operand) {
	std::string s = operand;
	return !s.empty() && std::find_if(s.begin(),
		s.end(), [](char c) { return !isdigit(c); }) == s.end();
}

bool FileReader::isImmHex(std::string operand) {
	std::string s = operand;
	return s.compare(0, 2, "0x") == 0
		&& s.size() > 2
		&& s.find_first_not_of("0123456789abcdefABCDEF", 2) == std::string::npos;
}

AddressingType FileReader::findAddressingMode(std::string operand) {
	std::regex op_dec{ ("([0-9]+)") };
	std::regex op_hex{ ("0x([0-9a-fA-F]+)") };
	std::regex op_sym_value{ "(\\&)([a-zA-Z_][a-zA-Z0-9]*)" };
	std::regex op_sym_mem{ "([a-zA-Z_][a-zA-Z0-9]*)" };
	std::regex op_mem_dec{ "(\\*)([0-9]+)" };
	std::regex op_mem_hex{ "(\\*)0x([0-9a-fA-F]+)" };
	std::regex op_reg{ "r[0-7]|sp|pc|psw" };
	std::regex op_reg_ind{ "(\\[)(r[0-7]|sp|pc|psw)(\\])" };
	std::regex op_reg_ind_dec{ "(r[0-7]|sp|pc|psw)(\\[)([0-9]+)(\\])" };
	std::regex op_reg_ind_hex{ "(r[0-7]|sp|pc|psw)(\\[)(0x[0-9a-fA-F]+)(\\])" };
	std::regex op_reg_ind_sym{ "(r[0-7]|sp|pc|psw)(\\[)([a-zA-Z_][a-zA-Z0-9]*)(\\])" };
	std::regex op_$_label{ "(\\$)([a-zA-Z_][a-zA-Z0-9]*)" };

	if (regex_match(operand, op_dec)) {
		return AddressingType::IMM;
	}
	if (regex_match(operand, op_hex)) {
		return AddressingType::IMM;
	}
	if (regex_match(operand, op_sym_value)) {
		return AddressingType::IMM;
	}
	if (regex_match(operand, op_reg)) {
		return AddressingType::REG_DIR;
	}
	if (regex_match(operand, op_reg_ind)) {
		return AddressingType::REG_IND;
	}
	if (regex_match(operand, op_reg_ind_dec)) {
		int posBeg = operand.find('[');
		int posEnd = operand.find(']');
		std::string val = operand.substr(posBeg + 1, posEnd - posBeg - 1);
		int n = stoi(val);
		if (n >= -128 && n <= 127)
			return AddressingType::REG_IND_POM8;
		else if (n >= -32768 && n <= 32767)
			return AddressingType::REG_IND_POM16;
	}
	if (regex_match(operand, op_reg_ind_hex)) {
		int posBeg = operand.find('[');
		int posEnd = operand.find(']');
		int len = posEnd - posBeg - 3;
		if (len >= 1 && len <= 2)
			return AddressingType::REG_IND_POM8;
		else if (len >= 3 && len <= 4)
			return AddressingType::REG_IND_POM16;
	}
	if (regex_match(operand, op_reg_ind_sym)) {
		return AddressingType::REG_IND_POM16;
	}
	if (regex_match(operand, op_$_label)) {
		return AddressingType::REG_IND_POM16;
	}
	if (regex_match(operand, op_sym_mem)) {
		return AddressingType::MEM;
	}
	if (regex_match(operand, op_mem_dec) || regex_match(operand, op_mem_hex)) {
		return AddressingType::MEM;
	}
	throw std::runtime_error("Addressing type is not recognized");
}

std::string FileReader::convertBinaryToHex(std::string binary) {
	int len = binary.length() - 4;
	std::string retVal = "";

	for (int i = 0; i <= len; i += 4) {
		std::string bin = binary.substr(i, 4);
		std::string hex = binaryToHex[bin];

		retVal += hex;
		if ((i + 4) % 8 == 0)
			retVal += " ";
	}

	return retVal;
}

std::string FileReader::formInstruction(std::queue<std::string>& tokens, std::string opstring, std::string opCode, int operandSize) {
	int num = numOfOperands[opstring];

	std::string retVal = opCode;

	if (operandSize == 8)
		retVal += "0";
	else
		retVal += "1";

	retVal += "00";

	locationCounter += 1;
	int instrLen;

	switch (num) {
	case 1: {
		std::string dstStr;
		std::string dst = tokens.front();
		tokens.pop();
		if (!dst.empty())
			dstStr = formOperand(dst, operandSize, true, 0);

		retVal += dstStr;

		break;
	}
	case 2: {
		std::string dstStr;
		std::string src;
		std::string dst = tokens.front();
		tokens.pop();
		if (!dst.empty()) {
			src = tokens.front();
			tokens.pop();
			int pad = getOperandLength(src, operandSize);
			dstStr = formOperand(dst, operandSize, true, pad);
		}

		std::string srcStr;
		if (!src.empty())
			srcStr = formOperand(src, operandSize, false, 0);

		retVal += (dstStr + srcStr);
		break;
	}
	}
	return retVal;
}

bool FileReader::checkDataValue(std::string type, int value) {
	if (type.compare("byte") == 0)
		return (abs(value) < 128);

	if (type.compare("word") == 0)
		return (abs(value) < 32768);

	return false;
}
