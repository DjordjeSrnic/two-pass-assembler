#include "FileWriter.h"

FileWriter::FileWriter(char* fname, std::map<std::string, Section> sections, int numSection, std::map<std::string, SymTabEntry> symbolTable, std::vector<RelTabEntry> relocationTable) {
	this->fileName = fname;
	outputFile.open(fname);

	this->sections = sections;

	numOfSections = numSection;

	this->symTable = symbolTable;
	this->relTable = relocationTable;
	relNum = 0;

	strNum = 0;
}


FileWriter::~FileWriter() {}

void FileWriter::close() {
	outputFile.close();
}

void FileWriter::writeSymTab(std::ofstream& output) {
	output << "#Tabela Simbola" << std::endl;
	output << "Ime Simbola" << " |" << "Sekcija" << " |" << "Offset" << " |" << "Scope" << " |" << "Tip simbola" << " | " << "Size" << "|" << "Number" <<  " |" << "Flags" << std::endl;

	for (auto it : symTable) {
		std::string name = it.first;
		SymTabEntry sym = it.second;
		std::string section = sym.section;
		std::string scope;
		if (sym.scope == ScopeType::GLOBAL)
			scope = "global";
		else
			scope = "local";
		
		std::string type = getTokenTypeS(sym.type);
		output << name << "|" << section << "|" << sym.offset << "|" << scope << "|" << type << "|" << sym.size << "|" << sym.id << "|" << sym.flags << std::endl;

	}
	output << "#end Symbol Table\n" << std::endl;
}

void FileWriter::writeSections(std::ofstream& output) {
	for (auto section : sections) {

		std::string name = section.first;

		Section sec = section.second;
		output << "#.ret" << name << std::endl;
		output << "#offset" << "  |  " << "tip" << "  |  " << "vr[" << name << "]:  |  " << "oper" << std::endl;

		for (RelTabEntry rel : relTable) {
			if (rel.section == name) {
				std::string tip;
				switch (rel.relType) {
				case ABS:
					tip = "R_386_16";
					break;
				case PCREL:
					tip = "R_386_PC16";
					break;
				}
				std::string symbol = rel.symbol;

				auto s = symTable.find(symbol);
				int symNumber = s->second.id;
				output << rel.offset << "|" << tip << "|" << symNumber<< "|" << rel.oper << std::endl;
			}
		}
		output << "#end" << std::endl;
		output << "" << std::endl;
		output << "#" << name << std::endl;
		
		
		std::map<int, std::string>::iterator it;

		for (it = sec.content.begin(); it != sec.content.end(); it++){
			output << it->second;
		}

		output << "" << std::endl;
		output << "#end" << std::endl;
		output << "" << std::endl;
	}
	output << ".END" << std::endl;
}

std::string FileWriter::getTokenTypeS(TokenType type) {
	switch (type)
	{
	case TokenType::LABEL:
		return "label";
	case TokenType::SECTION:
		return "section";
	case TokenType::LITERAL:
		return "literal";
	case TokenType::SYMBOL:
		return "symbol";
	default:
		return "error";
	}
}

void FileWriter::write() {

	writeSymTab(outputFile);

	writeSections(outputFile);

	std::cout << "KRAJ" << std::endl;
}
