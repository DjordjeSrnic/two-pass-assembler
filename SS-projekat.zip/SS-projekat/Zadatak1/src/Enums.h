#ifndef _ENUMS_H
#define _ENUMS_H

enum ScopeType { GLOBAL, LOCAL };
enum SectionType { START, TEXT, DATA, BSS, RODATA, UND };
enum TokenType { LABEL, LITERAL, SECTION, EXT_GLB, INSTRUCTION, INCORRECT, DIRECTIVE, SYMBOL, OP_DEC, OP_HEX, OP_SYM_VALUE, END, EQU };
enum InstructionName { HALT, XCHG, INT, MOV, ADD, SUB, MUL, DIV, CMP, NOT, AND, OR, XOR, TEST, SHL, SHR, PUSH, POP, JMP, JEQ, JNE, JGT, CALL, RET, IRET };
enum RelocationType { ABS, PCREL };
enum AddressingType { IMM, REG_DIR, REG_IND, REG_IND_POM8, REG_IND_POM16, MEM };

#endif