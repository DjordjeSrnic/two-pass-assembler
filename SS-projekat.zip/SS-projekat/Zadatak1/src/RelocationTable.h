#ifndef _RELOCATIONTABLE_H
#define _RELOCATIONTABLE_H

#include <iostream>
#include <string>
#include <vector>
#include "Enums.h"

typedef struct {
	std::string section;
	int offset;
	RelocationType relType;
	std::string symbol;
	std::string oper;
}RelTabEntry;

class RelocationTable
{
public:
	RelocationTable();

	~RelocationTable();

	void addEntry(std::string section, int offset, RelocationType relType, std::string symbol, std::string oper);

	std::vector<RelTabEntry> getTable();

	void print();

	int getSize();

private:
	std::vector<RelTabEntry> relTable;
	int num;
};

#endif

