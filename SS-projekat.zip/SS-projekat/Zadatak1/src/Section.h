#ifndef _SECTION_H
#define _SECTION_H

#include <iostream>
#include <string>
#include <map>

class Section {
public:
	Section(std::string _name, int _size);

	~Section();

	void addEntry(int offset, std::string hexContent);

	std::map<int, std::string> getContentTable();

	std::string getSectionName();

	int getSectionSize();

	int getTableSize();

	std::map<int, std::string> content;

private:
	std::string name;
	int size;
	int num;
};

#endif